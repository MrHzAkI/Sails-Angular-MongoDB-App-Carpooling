/**
 * VilleController
 *
 * @description :: Server-side logic for managing villes
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {

};
