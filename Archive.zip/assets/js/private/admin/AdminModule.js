/**
 * Created by Zaki on 29/12/2015.
 */
angular.module('AdminModule', ['toastr', 'ui.router', 'ngAnimate','VilleModule','AdmModule']);
