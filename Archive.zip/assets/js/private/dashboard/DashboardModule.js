

angular.module('DashboardModule', ['toastr', 'ui.router', 'ngAnimate','AnnonceModule','CompteModule','ReservationModule', 'AnnonceReservationModule']);
