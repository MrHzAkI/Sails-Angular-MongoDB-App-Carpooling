angular.module('SignupModule', ['toastr', 'compareTo']);
