/**
 * Created by safaa on 02/01/2016.
 */
angular.module('AdmModule',['toastr', 'compareTo']);
