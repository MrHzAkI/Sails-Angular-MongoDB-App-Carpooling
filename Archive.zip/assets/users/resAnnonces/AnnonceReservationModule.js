/**
 * Created by Zaki on 29/01/2016.
 */
angular.module('AnnonceReservationModule',['toastr', 'compareTo']);
