/**
 * Created by Zaki on 07/01/2016.
 */
angular.module('CompteModule',['toastr', 'compareTo']);
